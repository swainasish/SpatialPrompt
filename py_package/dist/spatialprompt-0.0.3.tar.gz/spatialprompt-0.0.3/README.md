# SpatialPrompt 
## Scalable and efficient cell type deconvolution and clustering in spatial transcriptomics